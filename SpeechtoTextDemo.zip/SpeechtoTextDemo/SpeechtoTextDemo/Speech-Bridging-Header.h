//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#import <googleapis/google/cloud/speech/v1/CloudSpeech.pbobjc.h>
#import <googleapis/google/cloud/speech/v1/CloudSpeech.pbrpc.h>

